import axios from "axios";

// export const authHeader = () => {
//     axios.defaults.headers = {
//       ...axios.defaults.headers,
//       Authorization: 'Bearer ' + token,
//       'Content-Type' : 'multipart/form-data'
//     };
//   } 
// };









